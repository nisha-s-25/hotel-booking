<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $name=$_POST["name"];
    $email=$_POST["email"];
    $room=$_POST["rooms"];
    $no_rooms=$_POST["number1"];
    $no_guests =$_POST["number2"];
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BOOKING STATUS</title>
        <style>
             body {
    font-family: Arial, sans-serif;
    margin: 0;
    background-color: grey;
    color: grey;
    background-size: cover;
    background-position: center;
}

.result {
    border: 1px solid #ccc;
    background-color:firebrick;
    padding: 20px;
    max-width: 400px;
    margin: 20px auto; /* Center the result box horizontally */
    margin-top: 250px;
}


.result h2 {
    margin-top: 0;
    color:white ;
}

.result p {
    margin-bottom: 10px;
    color:black;
}

  </style>
  </head>
  <body>
  <header>
  <div class="result">
            <h2>BOOKED SUCCESSFULLY</h2>
            <p><strong>Name:</strong> <?php echo $name; ?></p>
            <p><strong>Email:</strong> <?php echo $email; ?></p>
            <p><strong>Room Type:</strong> <?php echo $room; ?></p>
            <p><strong>No of rooms:</strong> <?php echo $no_rooms; ?></p>
            <p><strong>No of Guests:</strong><?php echo $no_guests;?></p>
        </div>
  </header>
  </body>
    </html>
<?php        
}
else{
    echo "BOOKING UNSUCCESSFUL";
}
$servername = "localhost";
$username = "root";
$password = "nisha";
$dbname = "registration";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql="INSERT INTO bookings VALUES ('$name','$email','$room','$no_rooms','$no_guests')";
if($conn->query($sql)===TRUE)
{
    echo "Success";
}
else{
    echo"error in creation";
}
$conn->close();
?>



